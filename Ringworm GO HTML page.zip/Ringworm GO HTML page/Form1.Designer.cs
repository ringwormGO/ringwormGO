﻿
namespace CS_Scientific_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.znanstveniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pretvraračTemperatureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.višekratniciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.promjenaBojeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.promjenaBojauputeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sakrijBojeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.očistiPorukeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vratiPorukeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zalugeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.andrejIStjepanToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.youTubeTutorialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mojaRodicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.Sqrt = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.btnExp = new System.Windows.Forms.Button();
            this.Odabir = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.button31 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtConvert = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button40 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.label6 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.lblGit = new System.Windows.Forms.LinkLabel();
            this.lblKamenje = new System.Windows.Forms.LinkLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.Odabir.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button1.Location = new System.Drawing.Point(12, 75);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(67, 63);
            this.button1.TabIndex = 0;
            this.button1.Text = "";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDisplay.Location = new System.Drawing.Point(12, 27);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(587, 42);
            this.txtDisplay.TabIndex = 1;
            this.txtDisplay.Text = "0";
            this.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "0";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.toolStripMenuItem14,
            this.toolStripMenuItem11,
            this.toolStripMenuItem7,
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(945, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardniToolStripMenuItem,
            this.znanstveniToolStripMenuItem,
            this.pretvraračTemperatureToolStripMenuItem,
            this.višekratniciToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // standardniToolStripMenuItem
            // 
            this.standardniToolStripMenuItem.Name = "standardniToolStripMenuItem";
            this.standardniToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.standardniToolStripMenuItem.Text = "Standardni";
            this.standardniToolStripMenuItem.Click += new System.EventHandler(this.standardniToolStripMenuItem_Click);
            // 
            // znanstveniToolStripMenuItem
            // 
            this.znanstveniToolStripMenuItem.Name = "znanstveniToolStripMenuItem";
            this.znanstveniToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.znanstveniToolStripMenuItem.Text = "Znanstveni";
            this.znanstveniToolStripMenuItem.Click += new System.EventHandler(this.znanstveniToolStripMenuItem_Click);
            // 
            // pretvraračTemperatureToolStripMenuItem
            // 
            this.pretvraračTemperatureToolStripMenuItem.Name = "pretvraračTemperatureToolStripMenuItem";
            this.pretvraračTemperatureToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.pretvraračTemperatureToolStripMenuItem.Text = "Pretvrarač temperature";
            this.pretvraračTemperatureToolStripMenuItem.Click += new System.EventHandler(this.pretvraračTemperatureToolStripMenuItem_Click);
            // 
            // višekratniciToolStripMenuItem
            // 
            this.višekratniciToolStripMenuItem.Name = "višekratniciToolStripMenuItem";
            this.višekratniciToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.višekratniciToolStripMenuItem.Text = "Višekratnici";
            this.višekratniciToolStripMenuItem.Click += new System.EventHandler(this.višekratniciToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.promjenaBojeToolStripMenuItem,
            this.promjenaBojauputeToolStripMenuItem,
            this.sakrijBojeToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // promjenaBojeToolStripMenuItem
            // 
            this.promjenaBojeToolStripMenuItem.Name = "promjenaBojeToolStripMenuItem";
            this.promjenaBojeToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.promjenaBojeToolStripMenuItem.Text = "Promjena boje (kalkulator)";
            this.promjenaBojeToolStripMenuItem.Click += new System.EventHandler(this.promjenaBojeToolStripMenuItem_Click);
            // 
            // promjenaBojauputeToolStripMenuItem
            // 
            this.promjenaBojauputeToolStripMenuItem.Name = "promjenaBojauputeToolStripMenuItem";
            this.promjenaBojauputeToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.promjenaBojauputeToolStripMenuItem.Text = "Promjena boja (upute)";
            this.promjenaBojauputeToolStripMenuItem.Click += new System.EventHandler(this.promjenaBojauputeToolStripMenuItem_Click);
            // 
            // sakrijBojeToolStripMenuItem
            // 
            this.sakrijBojeToolStripMenuItem.Name = "sakrijBojeToolStripMenuItem";
            this.sakrijBojeToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.sakrijBojeToolStripMenuItem.Text = "Sakrij boje";
            this.sakrijBojeToolStripMenuItem.Click += new System.EventHandler(this.sakrijBojeToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.očistiPorukeToolStripMenuItem,
            this.vratiPorukeToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // očistiPorukeToolStripMenuItem
            // 
            this.očistiPorukeToolStripMenuItem.Name = "očistiPorukeToolStripMenuItem";
            this.očistiPorukeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.očistiPorukeToolStripMenuItem.Text = "Očisti poruke.";
            this.očistiPorukeToolStripMenuItem.Click += new System.EventHandler(this.očistiPorukeToolStripMenuItem_Click);
            // 
            // vratiPorukeToolStripMenuItem
            // 
            this.vratiPorukeToolStripMenuItem.Name = "vratiPorukeToolStripMenuItem";
            this.vratiPorukeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.vratiPorukeToolStripMenuItem.Text = "Vrati poruke";
            this.vratiPorukeToolStripMenuItem.Click += new System.EventHandler(this.vratiPorukeToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zalugeToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // zalugeToolStripMenuItem
            // 
            this.zalugeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.andrejIStjepanToolStripMenuItem1,
            this.youTubeTutorialToolStripMenuItem,
            this.mojaRodicaToolStripMenuItem});
            this.zalugeToolStripMenuItem.Name = "zalugeToolStripMenuItem";
            this.zalugeToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.zalugeToolStripMenuItem.Text = "Zaluge";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(161, 22);
            this.toolStripMenuItem3.Text = "© 2021";
            // 
            // andrejIStjepanToolStripMenuItem1
            // 
            this.andrejIStjepanToolStripMenuItem1.Name = "andrejIStjepanToolStripMenuItem1";
            this.andrejIStjepanToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.andrejIStjepanToolStripMenuItem1.Text = "Andrej i Stjepan";
            // 
            // youTubeTutorialToolStripMenuItem
            // 
            this.youTubeTutorialToolStripMenuItem.Name = "youTubeTutorialToolStripMenuItem";
            this.youTubeTutorialToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.youTubeTutorialToolStripMenuItem.Text = "YouTube tutorial";
            // 
            // mojaRodicaToolStripMenuItem
            // 
            this.mojaRodicaToolStripMenuItem.Name = "mojaRodicaToolStripMenuItem";
            this.mojaRodicaToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.mojaRodicaToolStripMenuItem.Text = "Moja rodica";
            this.mojaRodicaToolStripMenuItem.Click += new System.EventHandler(this.mojaRodicaToolStripMenuItem_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(85, 75);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 63);
            this.button2.TabIndex = 4;
            this.button2.Text = "CE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(231, 209);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 63);
            this.button4.TabIndex = 10;
            this.button4.Text = "-";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Aritmethic_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(158, 209);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 63);
            this.button3.TabIndex = 9;
            this.button3.Text = "6";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(85, 209);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(67, 63);
            this.button5.TabIndex = 8;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(12, 209);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 63);
            this.button6.TabIndex = 7;
            this.button6.Text = "4";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(231, 140);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(67, 63);
            this.button7.TabIndex = 14;
            this.button7.Text = "+";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Aritmethic_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(158, 140);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(67, 63);
            this.button8.TabIndex = 13;
            this.button8.Text = "9";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(85, 140);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(67, 63);
            this.button9.TabIndex = 12;
            this.button9.Text = "8";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 140);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(67, 63);
            this.button10.TabIndex = 11;
            this.button10.Text = "7";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(158, 75);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(67, 63);
            this.button11.TabIndex = 15;
            this.button11.Text = "C";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(231, 75);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(67, 63);
            this.button12.TabIndex = 16;
            this.button12.Text = "±";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(12, 278);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(67, 63);
            this.button13.TabIndex = 17;
            this.button13.Text = "1";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(231, 278);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(67, 63);
            this.button14.TabIndex = 18;
            this.button14.Text = "×";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Aritmethic_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(158, 278);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(67, 63);
            this.button15.TabIndex = 19;
            this.button15.Text = "3";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(85, 278);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(67, 63);
            this.button16.TabIndex = 20;
            this.button16.Text = "2";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(386, 277);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(67, 63);
            this.button17.TabIndex = 36;
            this.button17.Text = "Tan";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(459, 277);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(67, 63);
            this.button18.TabIndex = 35;
            this.button18.Text = "Hex";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(532, 277);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(67, 63);
            this.button19.TabIndex = 34;
            this.button19.Text = "in x";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(313, 277);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(67, 63);
            this.button20.TabIndex = 33;
            this.button20.Text = "Tanh";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(532, 74);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(67, 63);
            this.button21.TabIndex = 32;
            this.button21.Text = "x^2";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // Sqrt
            // 
            this.Sqrt.Location = new System.Drawing.Point(459, 74);
            this.Sqrt.Name = "Sqrt";
            this.Sqrt.Size = new System.Drawing.Size(67, 63);
            this.Sqrt.TabIndex = 31;
            this.Sqrt.Text = "Sqrt";
            this.Sqrt.UseVisualStyleBackColor = true;
            this.Sqrt.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(532, 139);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(67, 63);
            this.button23.TabIndex = 30;
            this.button23.Text = "x^3";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(459, 139);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(67, 63);
            this.button24.TabIndex = 29;
            this.button24.Text = "Dec";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(386, 139);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(67, 63);
            this.button25.TabIndex = 28;
            this.button25.Text = "Sin";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(313, 139);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(67, 63);
            this.button26.TabIndex = 27;
            this.button26.Text = "Sinh";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(532, 208);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(67, 63);
            this.button27.TabIndex = 26;
            this.button27.Text = "1/x";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(459, 208);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(67, 63);
            this.button28.TabIndex = 25;
            this.button28.Text = "Bin";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(386, 208);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(67, 63);
            this.button29.TabIndex = 24;
            this.button29.Text = "Cos";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(313, 208);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(67, 63);
            this.button30.TabIndex = 23;
            this.button30.Text = "Cosh";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(386, 74);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(67, 63);
            this.btnLog.TabIndex = 22;
            this.btnLog.Text = "Log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Cambria Math", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button32.Location = new System.Drawing.Point(313, 74);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(67, 63);
            this.button32.TabIndex = 21;
            this.button32.Text = "π";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(231, 347);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(67, 63);
            this.button33.TabIndex = 40;
            this.button33.Text = "/";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.Aritmethic_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(158, 347);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(67, 63);
            this.button34.TabIndex = 39;
            this.button34.Text = "=";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(85, 347);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(67, 63);
            this.button35.TabIndex = 38;
            this.button35.Text = ",";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(12, 347);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(67, 63);
            this.button36.TabIndex = 37;
            this.button36.Text = "0";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(532, 346);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(67, 63);
            this.button37.TabIndex = 44;
            this.button37.Text = "%";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(459, 346);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(67, 63);
            this.button38.TabIndex = 43;
            this.button38.Text = "Oct";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(386, 346);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(67, 63);
            this.button39.TabIndex = 42;
            this.button39.Text = "Mod";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(313, 346);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(67, 63);
            this.btnExp.TabIndex = 41;
            this.btnExp.Text = "Exp";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // Odabir
            // 
            this.Odabir.Controls.Add(this.groupBox2);
            this.Odabir.Controls.Add(this.button31);
            this.Odabir.Controls.Add(this.button22);
            this.Odabir.Controls.Add(this.label4);
            this.Odabir.Controls.Add(this.label3);
            this.Odabir.Controls.Add(this.txtConvert);
            this.Odabir.Controls.Add(this.label2);
            this.Odabir.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Odabir.Location = new System.Drawing.Point(616, 30);
            this.Odabir.Name = "Odabir";
            this.Odabir.Size = new System.Drawing.Size(326, 379);
            this.Odabir.TabIndex = 45;
            this.Odabir.TabStop = false;
            this.Odabir.Text = "Temperatura";
            this.Odabir.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Yellow;
            this.groupBox2.Controls.Add(this.radioButton7);
            this.groupBox2.Controls.Add(this.radioButton4);
            this.groupBox2.Controls.Add(this.radioButton5);
            this.groupBox2.Controls.Add(this.radioButton6);
            this.groupBox2.Location = new System.Drawing.Point(6, 44);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 169);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Odabir";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(47, 35);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(104, 29);
            this.radioButton7.TabIndex = 6;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "C° to F°";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(47, 123);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(84, 29);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Kevin";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(47, 79);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(104, 29);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "F° to C°";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(48, -31);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(104, 29);
            this.radioButton6.TabIndex = 3;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "C° to F°";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(225, 335);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(87, 34);
            this.button31.TabIndex = 8;
            this.button31.Text = "Reset";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click_1);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(29, 335);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(120, 34);
            this.button22.TabIndex = 7;
            this.button22.Text = "Convert";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(207, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Load...";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Rezlutat";
            // 
            // txtConvert
            // 
            this.txtConvert.Location = new System.Drawing.Point(212, 216);
            this.txtConvert.Name = "txtConvert";
            this.txtConvert.Size = new System.Drawing.Size(100, 31);
            this.txtConvert.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Unesi vrijednost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(82, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(220, 13);
            this.label5.TabIndex = 46;
            this.label5.Text = "Samo dva broja zbrajaj/dijeli/množi/oduzimaj.";
            this.label5.Visible = false;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(223, 4);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 23);
            this.button40.TabIndex = 47;
            this.button40.Text = "Boja";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Visible = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(82, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 13);
            this.label6.TabIndex = 48;
            this.label6.Text = "Ne možeš dijeliti s nulom!!";
            this.label6.Visible = false;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(304, 4);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 23);
            this.button41.TabIndex = 49;
            this.button41.Text = "Boja";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Visible = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // lblGit
            // 
            this.lblGit.AutoSize = true;
            this.lblGit.Location = new System.Drawing.Point(583, 9);
            this.lblGit.Name = "lblGit";
            this.lblGit.Size = new System.Drawing.Size(220, 13);
            this.lblGit.TabIndex = 55;
            this.lblGit.TabStop = true;
            this.lblGit.Text = "https://vangutan2.wixsite.com/my-site/about";
            this.lblGit.Visible = false;
            // 
            // lblKamenje
            // 
            this.lblKamenje.AutoSize = true;
            this.lblKamenje.Location = new System.Drawing.Point(383, 9);
            this.lblKamenje.Name = "lblKamenje";
            this.lblKamenje.Size = new System.Drawing.Size(196, 13);
            this.lblKamenje.TabIndex = 54;
            this.lblKamenje.TabStop = true;
            this.lblKamenje.Text = "https://vangutan2.wixsite.com/kamenje";
            this.lblKamenje.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(738, 318);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 13);
            this.label7.TabIndex = 56;
            this.label7.Text = "Vidi našu specijaliziranu aplikaciju.";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(195, 22);
            this.toolStripMenuItem2.Text = "Standardni";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.standardniToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(195, 22);
            this.toolStripMenuItem4.Text = "Znanstveni";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.znanstveniToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(195, 22);
            this.toolStripMenuItem5.Text = "Pretvrarač temperature";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.pretvraračTemperatureToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(195, 22);
            this.toolStripMenuItem6.Text = "Višekratnici";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.višekratniciToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(39, 20);
            this.toolStripMenuItem7.Text = "Edit";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(214, 22);
            this.toolStripMenuItem8.Text = "Promjena boje (kalkulator)";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.promjenaBojeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(214, 22);
            this.toolStripMenuItem9.Text = "Promjena boja (upute)";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.promjenaBojauputeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(214, 22);
            this.toolStripMenuItem10.Text = "Sakrij boje";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.sakrijBojeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem11.Text = "View";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem12.Text = "Očisti poruke.";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.očistiPorukeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem13.Text = "Vrati poruke";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.vratiPorukeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem15});
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(52, 20);
            this.toolStripMenuItem14.Text = "About";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem16,
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19});
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem15.Text = "Zaluge";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem16.Text = "© 2021";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem17.Text = "Andrej i Stjepan";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem18.Text = "YouTube tutorial";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem19.Text = "Moja rodica";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.mojaRodicaToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 411);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblGit);
            this.Controls.Add(this.lblKamenje);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Odabir);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.Sqrt);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.btnLog);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "ringwormGO S Calculator (HRV); by C#";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.Odabir.ResumeLayout(false);
            this.Odabir.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem znanstveniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pretvraračTemperatureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem višekratniciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem promjenaBojeToolStripMenuItem;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button Sqrt;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.GroupBox Odabir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtConvert;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem zalugeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem andrejIStjepanToolStripMenuItem1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem očistiPorukeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem youTubeTutorialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vratiPorukeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem promjenaBojauputeToolStripMenuItem;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.ToolStripMenuItem mojaRodicaToolStripMenuItem;
        private System.Windows.Forms.LinkLabel lblGit;
        private System.Windows.Forms.LinkLabel lblKamenje;
        private System.Windows.Forms.ToolStripMenuItem sakrijBojeToolStripMenuItem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
    }
}