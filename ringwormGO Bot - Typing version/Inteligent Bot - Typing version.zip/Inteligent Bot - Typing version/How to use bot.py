import os


print("Keep utils folder and some other files in one folder!!")
print("All update will perform on this files!! In v2.0.0 all coming in one file.")
print("Navigate folder to Command Prompt or Terminal and type python [name of file]")

os.system('pause')